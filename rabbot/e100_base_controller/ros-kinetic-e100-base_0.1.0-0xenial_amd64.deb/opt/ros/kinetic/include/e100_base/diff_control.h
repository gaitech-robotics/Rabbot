/**
 * @file diff_control.h
 * @brief This is for the calculation of differential control
 * @author Rui-Jun Yan, hityrj@outlook.com
 * @version 1.0
 * @date 2018-03-27
 */

#include <string>
#include "ros/ros.h"
#include "nav_msgs/Odometry.h"

namespace GaiTech{
class DiffControl
{
	public:
		DiffControl(double dis, std::string frame_pose = "pose_link", std::string frame_twist = "twist_link");
		~DiffControl();

		double vl;
		double vr;
		nav_msgs::Odometry msg;

		void update(double linear, double angular);
		void GetOdom(int N = 2, double lf = 0.0, double rf = 0.0, 
				double lb = 0.0, double rb = 0.0, ros::Time t = ros::Time::now());


	private:
		bool StartFlag;
		double x;
		double y;
		double angle;

		double WheelGauge;

		double LinearOdom;
		double AngularOdom;

		std::string FramePose;
		std::string FrameTwist;

		double LastTimeStamp;

		void GetVel(int N, double lf, double rf, double lb, double rb);
		void PoseIntegrate(ros::Time t);
};

}// Namespace
